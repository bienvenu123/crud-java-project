/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
public class insert extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
    if(request.getParameter("submit")!=null){
      Date y= new Date();
    
      
String pname=request.getParameter("pname");
String pn=request.getParameter("pnational");
String pi=request.getParameter("pidentity");
//String date=request.getParameter("mdate");
//String date1=request.getParameter("xdate");
int px=Integer.parseInt(pi);
String req=request.getParameter("mdate");
String facu=request.getParameter("faculty");
String dpt=request.getParameter("department");
String doc=request.getParameter("doc");


Connection con;
PreparedStatement pst;
ResultSet rs;
Statement st;
try{
Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost/prison","root","");
st=con.createStatement();

 java.sql.Date  sql = new java.sql.Date(new java.util.Date().getTime());
String qry="INSERT INTO becky(name,nation,identity,edate,faculty,department,doc)"
       + " VALUES ('"+pname+"','"+pn+"','"+px+"','"+sql+"','"+facu+"','"+dpt+"','"+doc+"')";

st.executeUpdate(qry);
response.sendRedirect("display.jsp");
}catch(Exception e){
out.print(e.getMessage());
}
        }
        }
    }
public void doPost(HttpServletRequest req,  HttpServletResponse res)
throws ServletException, IOException{
processRequest(req,res);
}
}



    
