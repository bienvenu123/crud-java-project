import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Login extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String name = request.getParameter("name");
        String pass = request.getParameter("pass");
        
        if(Validate.checkUser(name, pass))
        {
            RequestDispatcher rs = request.getRequestDispatcher("adminhome.html");
            rs.forward(request, response);
        }
        else
        {
            out.print("<html>");
         out.print("<head>");
          out.print("<style>.message{margin-left:555px;font-family:lato;color:red;}</style>");
          out.print("</head>");
        
         out.print("<body>");
         
           out.println("<div class='message'>Username or Password incorrect</div>");
           RequestDispatcher rs = request.getRequestDispatcher("admin.html");
           rs.include(request, response);
           
            out.print("<body>");
        }
    }}
  