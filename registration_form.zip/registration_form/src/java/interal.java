
import java.util.Locale;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class interal {
    public static void main(String[] args) {  
Locale[] locales = { new Locale("en", "US"),  
 new Locale("kis", "KIS"), new Locale("kiny", "KINY") };   
  
for (int i=0; i< locales.length; i++) {   
 String displayLanguage = locales[i].getDisplayLanguage(locales[i]);   
 System.out.println(locales[i].toString() + ": " + displayLanguage);   
}   
}  
}
