
import com.sun.corba.se.impl.protocol.giopmsgheaders.Message;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Properties;
import javax.websocket.Session;
import sun.rmi.transport.Transport;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class email {
    public void sendMail(String recipient) throws Exception {
        Properties properties = new Properties();
//        mail.smtp.host=smtp.gmail.com, mail.smtp.port=25, mail.smtp.auth=true mail.smtp.starttls.enable=true
        
        
        properties.put("mail.smtp.auth", true);
        properties.put("mail.smtp.starttls.enable", true);
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        String myAccountEmail = "ndagijimanapierre96@gmail.com";
        String password = "qtnpdzlxhjmngiux";

        Session session = Session.getInstance(properties, new Authenticator() {

            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myAccountEmail, password);
            }
        });
        Message message = prepareMessage(session, myAccountEmail, recipient);
        Transport.send(message);
        System.out.println("The message sent successfully");
       
    }
    
 private Message prepareMessage(Session session,String myAccountEmail,String recipient) {
        try {
            Message message=new MimeMessage(session);
            message.setFrom(new InternetAddress(myAccountEmail));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            message.setSubject("Student Addmission");
            message.setText("hey there,\n Your addmission form has been submitted successfully");
            return message;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
