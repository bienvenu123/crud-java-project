/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
public class userinsert extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           if(request.getParameter("submit")!=null){
   
    
String pname=request.getParameter("username");
String pn=request.getParameter("name");
String pi=request.getParameter("tel");

int px=Integer.parseInt(pi);
String req=request.getParameter("pass");


Connection con;
PreparedStatement pst;
ResultSet rs;
Statement st;
try{
Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost/prison","root","");
st=con.createStatement();

String qry="INSERT INTO users(username,name,tel,pass)"
       + " VALUES ('"+pname+"','"+pn+"','"+px+"','"+req+"')";
st.executeUpdate(qry);
response.sendRedirect("index.html");
}catch(Exception e){
out.print(e.getMessage());

}
        }
        }
    }
public void doPost(HttpServletRequest req,  HttpServletResponse res)
throws ServletException, IOException{
        try {
            processRequest(req,res);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(userinsert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(userinsert.class.getName()).log(Level.SEVERE, null, ex);
        }
}
}