import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class uselogin extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String pass = request.getParameter("pass");
        
        if(valiad.checkUser(username, pass))
        {
            RequestDispatcher rs = request.getRequestDispatcher("hh.html");
            rs.forward(request, response);
        }
        else
        {
            out.print("<html>");
         out.print("<head>");
          out.print("<style>.message{margin-left:555px;font-family:lato;color:red;}</style>");
          out.print("</head>");
        
         out.print("<body>");
         
           out.println("<div class='message'>Username or Password incorrect</div>");
           RequestDispatcher rs = request.getRequestDispatcher("index.html");
           rs.include(request, response);
           
            out.print("<body>");
        }
    }}
  